public static Boolean loginUser(Boolean username, Boolean password){
        //Flag_1
        username = false;

        //Flag_2
        password = false;

        if (username = username){
            username = true;
        }
        if (password = password){
            password = true;
        }

        return password && username;
    }

    public static void loginStatus(String username, String password, String userFirstName, String userLastName){
        while (!(checkUsername(username) && checkPasswordComplexity(password))){
            Scanner input = new Scanner(System.in);
            
            System.out.println("Username or password is incorrect, please try again");
            //Ask the user to enter there username
                System.out.println("-------------------------");
                System.out.print("Enter your username: ");
                username = input.nextLine();
                System.out.println("-------------------------");
        
                
                //Ask the user to enter there password
                System.out.println(" ");
                System.out.println("-------------------------");
                System.out.print("Enter your password: ");
                password = input.nextLine();
                System.out.println("-------------------------");
        
        }
        if (checkUsername(username) && checkPasswordComplexity(password)){
            System.out.println("Welcome " + userFirstName + ", " + userLastName + " it is nice to see you again");
        }
    }
    public static String registerUser(String password, String username){
        if (checkUsername(username)){
            if (checkPasswordComplexity(password)){
                return "The two above conditions have been met, and the user has been registered successfully";
            }
            else{ 
                while (!(numOfChar && capitalLetter && num && specialChar)){
                    Scanner input = new Scanner(System.in);
            
                    
                    System.out.println(" ");
                    System.out.println("-------------------------");
                    System.out.println("Password is not correctly formatted, please ensure that your username contains eight chararters, capital letter, number and special character");
                    System.out.print("Enter password again: ");
                    password = input.nextLine();

                    numOfChar = password.length() >= 8;
                    
                    for (int index = 0; index < password.length(); index++) {
                        char eachChar = password.charAt(index);
                
                        if (Character.isUpperCase(eachChar)) {
                            capitalLetter = true;
                        }
                
                        if (Character.isDigit(eachChar)) {
                            num = true;
                        }
                
                        if (!Character.isLetterOrDigit(eachChar)) {
                            specialChar = true;
                        }
                    }
                }
            }
        }
        else {
            while (!(numOfChar && hasUnderscore)){
                Scanner input = new Scanner(System.in);
                
                System.out.println(" ");
                System.out.println("-------------------------");
                System.out.println("Username is not correctly ensure that your username cntains an underscore and is no more than five charaters in length");
                System.out.print("Enter your username: ");
                username = input.nextLine();

                numOfChar = username.length() <= 5;
                hasUnderscore = username.contains("_");
            }
        }
    }
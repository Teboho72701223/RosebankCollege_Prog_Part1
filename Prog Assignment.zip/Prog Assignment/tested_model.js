import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	            Scanner input = new Scanner(System.in);
	    
	    //Declaration
	    int choice;
	    String username = "Te_bo";
	    String password = "Plant@230";
	    String cellPhoneNum;
	    String userFirstName = "Teboho";
	    String userLastName = "Sejane";
	    String usernameEntered;
	    String passwordEntered;
	    
		//Repeat till the user chooses the correct option
        do {
            System.out.println("--- MENU ---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("-1. Exit");
            System.out.print("Choose an option: ");
            choice = input.nextInt();
            input.nextLine();
            System.out.println("-------------------------");
        
            if (choice == 1){
                System.out.println("Enter your login details");
        
                //Space
                System.out.println(" ");
        
                //Ask the user to enter there username
                System.out.print("Enter your username: ");
                usernameEntered = input.nextLine();
        
                //Ask the user to enter there password
                System.out.println("-------------------------");
                System.out.print("Enter your password: ");
                passwordEntered = input.nextLine();
                loginStatus(username, password, userFirstName, userLastName, usernameEntered, passwordEntered);
                System.out.println("-------------------------");
                System.out.println(" ");
            }
        
            else if (choice == 2){
                System.out.println("Thank you for using or app, Enter your details");
        
                //Ask the user to enter their first name
                System.out.println(" ");
                System.out.print("Enter your first name: ");
                userFirstName = input.nextLine();
                System.out.println("-------------------------");
        
                //Ask the user to enter their last name
                System.out.println(" ");
                System.out.print("Enter your last name: ");
                userLastName = input.nextLine();
                System.out.println("-------------------------");
        
                //Ask the user to enter their phone number
                System.out.println(" ");
                System.out.println("Please enter your cellphone number, the cellphone number must contain");
                System.out.println("- International country code");
                System.out.println("- Ten character long number");
                System.out.print("Enter your cellphone number: ");
                cellPhoneNum = input.nextLine();
                checkCellPhoneNumber(cellPhoneNum);
                System.out.println("-------------------------");
        
        
                System.out.println(" ");
                System.out.println("Please enter a username, the username must have:");
                System.out.println("- Five characters");
                System.out.println("- Underscore");
                System.out.print("Enter your username: ");
                usernameEntered = input.nextLine();
                System.out.println("-------------------------");
        
                System.out.println(" ");
                System.out.println("Please enter a password, the password must have:");
                System.out.println("- Eight or more charaters");
                System.out.println("- A capital letter");
                System.out.println("- A number");
                System.out.println("- A special character");
                System.out.print("Enter your password: ");
                passwordEntered = input.nextLine();
                registerUser(passwordEntered, usernameEntered);
                System.out.println("-------------------------");
                }
        } while (choice != -1);

        // Closing message
        System.out.println("Goodbye!");
	}
	//Checks if the username is in the correct format
    public static Boolean checkUsername(String username) {
        //Check if the username has five characters or not
        Boolean numOfChar = username.length() >= 5;

        //Check for the underscore
        Boolean hasUnderscore = false;

        //Looks at each charater to check what is the character at the index
        //Referencing
        for (int index = 0; index < username.length(); index++){
            String eachChar = String.valueOf(username.charAt(index));

            //Check if the underscore is there if there the hasUnderscore changes to true
            if (eachChar.equals("_")){
                hasUnderscore = true;
                break;
            }
        }

        //Final Decision
        return numOfChar && hasUnderscore;
    }

    public static Boolean checkPasswordComplexity(String password){
        //Cheaks for eight chararters
        Boolean numOfChar = password.length() >= 8;

        //Checks for a capital letter
        Boolean capitalLetter = false;

        //Checks for a number
        Boolean num = false;

        //Checks for a special character
        Boolean specialChar = false;

        for (int index = 0; index < password.length(); index++) {
            char eachChar = password.charAt(index);
        
            if (Character.isUpperCase(eachChar)) {
                capitalLetter = true;
            }
        
            if (Character.isDigit(eachChar)) {
                num = true;
            }
        
            if (!Character.isLetterOrDigit(eachChar)) {
                specialChar = true;
            }
        }

        //Final Decision
        return numOfChar && capitalLetter && num && specialChar;
    }

    public static Boolean checkCellPhoneNumber(String cellPhoneNum){
        Scanner input = new Scanner(System.in);
        
        //Flag_1
        boolean countryCode = cellPhoneNum.startsWith("+27");

        //Flag_2
        boolean lengthOfCellNum = cellPhoneNum.length() == 12;

        //Make a loop to make sure the user inputs the right answer
        //Final decsion
        while (!(countryCode && lengthOfCellNum)){
            System.out.println("Cellphone number incorrectly formatted or does not contain international code");
            
            System.out.println(" ");
            
            System.out.print("Enter your number again: ");
            cellPhoneNum = input.nextLine();
            
            countryCode = cellPhoneNum.startsWith("+27");
            lengthOfCellNum = cellPhoneNum.length() == 12;
            
        }
        if (countryCode && lengthOfCellNum){
            System.out.println("Cellphone number successfully added");
        }
        return countryCode && lengthOfCellNum;
    }

    public static String registerUser(String password, String username){
        Scanner input = new Scanner(System.in);
        
        if (!(checkUsername(username))) {
            while (!(checkUsername(username))){
                System.out.println(" ");
                System.out.println("-------------------------");
                System.out.println("Username is not correctly ensure that your username cntains an underscore and is no more than five charaters in length");
                System.out.print("Enter your username: ");
                username = input.nextLine();

                checkUsername(username);
            }
            
            if (checkUsername(username)){
                System.out.println("Username successfully captured");
            }
        }
        
        if (!(checkPasswordComplexity(password))){
            while (!(checkPasswordComplexity(password))){
                System.out.println(" ");
                System.out.println("-------------------------");
                System.out.println("Password is not correctly formatted, please ensure that your username contains eight chararters, capital letter, number and special character");
                System.out.print("Enter password again: ");
                password = input.nextLine();

                checkPasswordComplexity(password);
            }
            
            if (checkPasswordComplexity(password)){
                System.out.println("Password successfully captured");
            }
        }
        
        return "The two above conditions have been met, and the user has been registered successfully";
    }

    public static boolean loginUser(String enteredUsername, String enteredPassword,
                                String username, String password) {

    return enteredUsername.equals(username) &&
           enteredPassword.equals(password);
    }

    public static String loginStatus(String username, String password, 
                                String userFirstName, String userLastName, 
                                String enteredUsername, String enteredPassword){

    Scanner input = new Scanner(System.in);

    while (!loginUser(enteredUsername, enteredPassword, username, password)) {

        System.out.println("Username or password is incorrect, please try again");
        System.out.println(" ");
        System.out.println("-------------------------");
        System.out.print("Enter your username: ");
        enteredUsername = input.nextLine();

        System.out.println("-------------------------");
        System.out.print("Enter your password: ");
        enteredPassword = input.nextLine();
    }

    return "Welcome " + userFirstName + ", " + userLastName + " it is nice to see you again";
    }    
}